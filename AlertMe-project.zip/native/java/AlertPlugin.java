package com.alertme.app;

import android.Manifest;
import android.app.Activity;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@CapacitorPlugin(name = "AlertPlugin")
public class AlertPlugin extends Plugin {

    private final Handler ui = new Handler(Looper.getMainLooper());
    private MediaPlayer preview;

    // ------------------------------------------------------------ state

    @PluginMethod
    public void getState(PluginCall call) {
        Context c = getContext();
        JSObject r = new JSObject();
        r.put("armed", GuardService.armed);
        r.put("arming", GuardService.arming);
        r.put("armingEndsAt", GuardService.armingEndsAt);
        r.put("ringing", GuardService.ringing);
        r.put("reason", GuardService.reason);
        r.put("now", System.currentTimeMillis());
        int pct = -1;
        boolean charging = false;
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            if (level >= 0 && scale > 0) pct = Math.round(level * 100f / scale);
            charging = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
        }
        r.put("battery", pct);
        r.put("charging", charging);
        call.resolve(r);
    }

    @PluginMethod
    public void saveConfig(PluginCall call) {
        String json = call.getString("json", "{}");
        getContext().getSharedPreferences(GuardService.PREFS, 0).edit().putString("config", json).apply();
        call.resolve();
    }

    // ------------------------------------------------------------ guard control

    private void sendToService(String action, String reason) {
        Intent i = new Intent(getContext(), GuardService.class);
        i.setAction(action);
        if (reason != null) i.putExtra(GuardService.EXTRA_REASON, reason);
        getContext().startForegroundService(i);
    }

    @PluginMethod
    public void arm(PluginCall call) {
        try {
            sendToService(GuardService.ACTION_ARM, null);
            call.resolve();
        } catch (Exception e) {
            call.reject("arm failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void disarm(PluginCall call) {
        try {
            if (GuardService.isActive()) sendToService(GuardService.ACTION_DISARM, null);
            call.resolve();
        } catch (Exception e) {
            call.reject("disarm failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void testAlarm(PluginCall call) {
        try {
            sendToService(GuardService.ACTION_TRIGGER, "test");
            call.resolve();
        } catch (Exception e) {
            call.reject("test failed: " + e.getMessage());
        }
    }

    /** Stops a ringing alarm, but only after the phone itself has been unlocked. */
    @PluginMethod
    public void stopAlarm(final PluginCall call) {
        final Activity a = getActivity();
        if (!GuardService.ringing) {
            call.resolve(stopped(true));
            return;
        }
        final KeyguardManager km = (KeyguardManager) getContext().getSystemService(Context.KEYGUARD_SERVICE);
        if (km != null && a != null && km.isKeyguardLocked()) {
            a.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    km.requestDismissKeyguard(a, new KeyguardManager.KeyguardDismissCallback() {
                        @Override
                        public void onDismissSucceeded() {
                            doStop(call);
                        }

                        @Override
                        public void onDismissCancelled() {
                            call.resolve(stopped(false));
                        }

                        @Override
                        public void onDismissError() {
                            call.resolve(stopped(false));
                        }
                    });
                }
            });
        } else {
            doStop(call);
        }
    }

    private void doStop(PluginCall call) {
        try {
            sendToService(GuardService.ACTION_STOP_ALARM, null);
            call.resolve(stopped(true));
        } catch (Exception e) {
            call.reject("stop failed: " + e.getMessage());
        }
    }

    private JSObject stopped(boolean ok) {
        JSObject r = new JSObject();
        r.put("stopped", ok);
        return r;
    }

    // ------------------------------------------------------------ history

    @PluginMethod
    public void getLogs(PluginCall call) {
        JSObject r = new JSObject();
        r.put("json", LogStore.json(getContext()));
        call.resolve(r);
    }

    @PluginMethod
    public void clearLogs(PluginCall call) {
        LogStore.clear(getContext());
        call.resolve();
    }

    // ------------------------------------------------------------ permissions

    @PluginMethod
    public void getPermissions(PluginCall call) {
        Context c = getContext();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        JSObject r = new JSObject();
        r.put("sdk", Build.VERSION.SDK_INT);
        r.put("notifications", nm != null && nm.areNotificationsEnabled());
        r.put("battery", pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName()));
        r.put("fullScreen", Build.VERSION.SDK_INT < 34 || (nm != null && nm.canUseFullScreenIntent()));
        r.put("install", c.getPackageManager().canRequestPackageInstalls());
        call.resolve(r);
    }

    @PluginMethod
    public void requestPermission(PluginCall call) {
        String name = call.getString("name", "");
        Activity a = getActivity();
        Context c = getContext();
        if (a == null) {
            call.reject("no activity");
            return;
        }
        Uri pkg = Uri.parse("package:" + c.getPackageName());
        Intent i = null;
        if ("notifications".equals(name)) {
            boolean asked = c.getSharedPreferences(GuardService.PREFS, 0).getBoolean("askedNotif", false);
            if (Build.VERSION.SDK_INT >= 33 && !asked
                    && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                c.getSharedPreferences(GuardService.PREFS, 0).edit().putBoolean("askedNotif", true).apply();
                ActivityCompat.requestPermissions(a, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7001);
                call.resolve();
                return;
            }
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, c.getPackageName());
        } else if ("battery".equals(name)) {
            i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg);
        } else if ("fullScreen".equals(name)) {
            if (Build.VERSION.SDK_INT >= 34) {
                i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg);
            }
        } else if ("install".equals(name)) {
            i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, pkg);
        }
        if (i != null) openSettings(a, i, pkg);
        call.resolve();
    }

    private void openSettings(Activity a, Intent i, Uri pkg) {
        try {
            a.startActivity(i);
        } catch (Exception e) {
            try {
                a.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg));
            } catch (Exception ignored) {
            }
        }
    }

    // ------------------------------------------------------------ tone preview

    @PluginMethod
    public void previewTone(PluginCall call) {
        String name = call.getString("name", "siren");
        stopPreview();
        try {
            Context c = getContext();
            int id = c.getResources().getIdentifier(name, "raw", c.getPackageName());
            if (id == 0) {
                call.reject("tone not found");
                return;
            }
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            AssetFileDescriptor afd = c.getResources().openRawResourceFd(id);
            try {
                mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            } finally {
                afd.close();
            }
            mp.setLooping(true);
            mp.prepare();
            mp.start();
            synchronized (this) {
                preview = mp;
            }
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    stopPreview();
                }
            }, 2500);
            call.resolve();
        } catch (Exception e) {
            stopPreview();
            call.reject("preview failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void stopPreviewTone(PluginCall call) {
        stopPreview();
        call.resolve();
    }

    private synchronized void stopPreview() {
        if (preview != null) {
            try {
                preview.stop();
            } catch (Exception ignored) {
            }
            try {
                preview.release();
            } catch (Exception ignored) {
            }
            preview = null;
        }
    }

    @Override
    protected void handleOnDestroy() {
        stopPreview();
        super.handleOnDestroy();
    }

    // ------------------------------------------------------------ updates

    @PluginMethod
    public void getAppInfo(PluginCall call) {
        try {
            Context c = getContext();
            PackageInfo info = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            JSObject r = new JSObject();
            r.put("versionName", info.versionName == null ? "" : info.versionName);
            r.put("versionCode", Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("info failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void installUpdate(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null || !url.startsWith("https://")) {
            call.reject("bad url");
            return;
        }
        Context c = getContext();
        if (!c.getPackageManager().canRequestPackageInstalls()) {
            Activity a = getActivity();
            if (a != null) {
                Uri pkg = Uri.parse("package:" + c.getPackageName());
                openSettings(a, new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, pkg), pkg);
            }
            JSObject r = new JSObject();
            r.put("needPermission", true);
            call.resolve(r);
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                downloadAndInstall(url, call);
            }
        }).start();
    }

    private void downloadAndInstall(String link, PluginCall call) {
        HttpURLConnection con = null;
        try {
            File dir = new File(getContext().getCacheDir(), "updates");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("cache dir");
            File out = new File(dir, "update.apk");
            URL u = new URL(link);
            for (int hop = 0; hop < 6; hop++) {
                con = (HttpURLConnection) u.openConnection();
                con.setInstanceFollowRedirects(false);
                con.setConnectTimeout(15000);
                con.setReadTimeout(30000);
                con.setRequestProperty("User-Agent", "AlertMe-Updater");
                int code = con.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = con.getHeaderField("Location");
                    con.disconnect();
                    con = null;
                    if (loc == null) throw new IOException("redirect without location");
                    u = new URL(u, loc);
                    continue;
                }
                if (code != 200) throw new IOException("HTTP " + code);
                break;
            }
            if (con == null) throw new IOException("too many redirects");
            long total = con.getContentLengthLong();
            long done = 0;
            int lastPct = -1;
            try (InputStream in = con.getInputStream(); FileOutputStream fo = new FileOutputStream(out)) {
                byte[] buf = new byte[32768];
                int n;
                while ((n = in.read(buf)) != -1) {
                    fo.write(buf, 0, n);
                    done += n;
                    if (total > 0) {
                        int pct = (int) (done * 100 / total);
                        if (pct != lastPct) {
                            lastPct = pct;
                            JSObject p = new JSObject();
                            p.put("percent", pct);
                            notifyListeners("updateProgress", p);
                        }
                    }
                }
            }
            if (out.length() < 100000) throw new IOException("file too small");
            installApk(out);
            JSObject r = new JSObject();
            r.put("started", true);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("download failed: " + e.getMessage());
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private void installApk(File apk) {
        Context c = getContext();
        Uri uri = FileProvider.getUriForFile(c, c.getPackageName() + ".fileprovider", apk);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }
}
