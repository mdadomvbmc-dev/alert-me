package com.alertme.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import org.json.JSONObject;

/**
 * Keeps the phone guarded. Runs as a foreground service so that it survives
 * the screen being off and the app being swiped away.
 *
 * Reason codes (shown in Bangla by the web UI): motion, charger, pocket, test.
 */
public class GuardService extends Service implements SensorEventListener {

    static final String PREFS = "alertme";
    static final String ACTION_ARM = "com.alertme.app.ARM";
    static final String ACTION_DISARM = "com.alertme.app.DISARM";
    static final String ACTION_TRIGGER = "com.alertme.app.TRIGGER";
    static final String ACTION_STOP_ALARM = "com.alertme.app.STOP_ALARM";
    static final String EXTRA_REASON = "reason";
    static final String EXTRA_ALARM = "alarm";

    private static final String CH_GUARD = "alertme_guard";
    private static final String CH_ALARM = "alertme_alarm";
    private static final int ID_GUARD = 11;
    private static final int ID_ALARM = 12;

    // ---- state read by AlertPlugin / MainActivity ----
    static volatile boolean arming = false;
    static volatile boolean armed = false;
    static volatile boolean ringing = false;
    static volatile long armingEndsAt = 0L;
    static volatile String reason = "";

    static boolean isActive() {
        return arming || armed || ringing;
    }

    static boolean volumeLockOn(Context c) {
        try {
            JSONObject o = new JSONObject(c.getSharedPreferences(PREFS, 0).getString("config", "{}"));
            return o.optBoolean("volumeLock", true);
        } catch (Exception e) {
            return true;
        }
    }

    // ---- internals ----
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SensorManager sensors;
    private Sensor accel;
    private Sensor prox;
    private AudioManager audio;
    private AudioFocusRequest focusReq;
    private MediaPlayer player;
    private Vibrator vibrator;
    private CameraManager camera;
    private String torchId;
    private boolean torchOn = false;
    private PowerManager.WakeLock cpuLock;
    private PowerManager.WakeLock screenLock;

    private boolean motionMode = true;
    private boolean chargerMode = false;
    private boolean pocketMode = false;
    private float motionThreshold = 1.1f;

    private float lx, ly, lz;
    private boolean hasLast = false;
    private int hits = 0;
    private long firstHitAt = 0L;
    private boolean sawNear = false;

    private int maxAlarmVol = 0;
    private boolean volLock = true;
    private boolean flashOn = true;
    private boolean vibrateOn = true;
    private long lastSoundTry = 0L;

    private final Runnable armNowTask = new Runnable() {
        @Override
        public void run() {
            armNow();
        }
    };

    private final Runnable enforcer = new Runnable() {
        @Override
        public void run() {
            if (!ringing) return;
            try {
                if (audio != null && maxAlarmVol > 0 && volLock
                        && audio.getStreamVolume(AudioManager.STREAM_ALARM) != maxAlarmVol) {
                    audio.setStreamVolume(AudioManager.STREAM_ALARM, maxAlarmVol, 0);
                }
            } catch (Exception ignored) {
            }
            long now = SystemClock.elapsedRealtime();
            if (!playerHealthy() && now - lastSoundTry > 1500) {
                lastSoundTry = now;
                releasePlayer();
                startSound();
            }
            handler.postDelayed(this, 250);
        }
    };

    private final Runnable torchTask = new Runnable() {
        @Override
        public void run() {
            if (!ringing || !flashOn) return;
            setTorch(!torchOn);
            handler.postDelayed(this, 350);
        }
    };

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String a = intent == null ? null : intent.getAction();
            if (Intent.ACTION_POWER_DISCONNECTED.equals(a)) {
                if (armed && chargerMode && !ringing) trigger("charger", true);
            } else if (Intent.ACTION_USER_PRESENT.equals(a)) {
                if (ringing && readCfg().optBoolean("autoStopOnUnlock", false)) disarmAndStop();
            }
        }
    };

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (sensors != null) {
            accel = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            prox = sensors.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        }
        createChannels();
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alertme:guard");
        cpuLock.setReferenceCounted(false);
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_POWER_DISCONNECTED);
        f.addAction(Intent.ACTION_USER_PRESENT);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receiver, f);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        goForeground();
        String action = intent == null ? null : intent.getAction();
        if (action == null) {
            restoreAfterRestart();
            return START_STICKY;
        }
        switch (action) {
            case ACTION_ARM:
                beginArming();
                return START_STICKY;
            case ACTION_TRIGGER:
                trigger(intent.getStringExtra(EXTRA_REASON) == null ? "test" : intent.getStringExtra(EXTRA_REASON), true);
                return START_STICKY;
            case ACTION_DISARM:
            case ACTION_STOP_ALARM:
            default:
                disarmAndStop();
                return START_NOT_STICKY;
        }
    }

    @Override
    public void onDestroy() {
        cancelAll();
        try {
            unregisterReceiver(receiver);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ---------------------------------------------------------------- arming

    private void beginArming() {
        cancelAll();
        loadModes();
        int delay = Math.max(0, Math.min(120, readCfg().optInt("delaySec", 10)));
        arming = true;
        armingEndsAt = System.currentTimeMillis() + delay * 1000L;
        prefs().edit().putBoolean("armed", true).putBoolean("ringing", false).apply();
        acquireCpu();
        updateGuardNotification();
        handler.postDelayed(armNowTask, delay * 1000L);
    }

    private void loadModes() {
        JSONObject c = readCfg();
        motionMode = c.optBoolean("motion", true);
        chargerMode = c.optBoolean("charger", false);
        pocketMode = c.optBoolean("pocket", false);
        int s = c.optInt("sens", 2);
        motionThreshold = s <= 1 ? 2.2f : (s >= 3 ? 0.55f : 1.1f);
    }

    private void armNow() {
        arming = false;
        armed = true;
        armingEndsAt = 0L;
        hasLast = false;
        hits = 0;
        sawNear = false;
        acquireCpu();
        if (sensors != null) {
            if (motionMode && accel != null) {
                sensors.registerListener(this, accel, SensorManager.SENSOR_DELAY_UI);
            }
            if (pocketMode && prox != null) {
                sensors.registerListener(this, prox, SensorManager.SENSOR_DELAY_NORMAL);
            }
        }
        updateGuardNotification();
    }

    private void restoreAfterRestart() {
        SharedPreferences p = prefs();
        if (p.getBoolean("ringing", false)) {
            loadModes();
            trigger(p.getString("reason", "motion"), false);
        } else if (p.getBoolean("armed", false)) {
            loadModes();
            armNow();
        } else {
            disarmAndStop();
        }
    }

    private void disarmAndStop() {
        cancelAll();
        prefs().edit().putBoolean("armed", false).putBoolean("ringing", false).apply();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void cancelAll() {
        handler.removeCallbacksAndMessages(null);
        stopSensors();
        stopRinging();
        arming = false;
        armed = false;
        ringing = false;
        armingEndsAt = 0L;
        if (cpuLock != null && cpuLock.isHeld()) cpuLock.release();
    }

    private void stopSensors() {
        if (sensors != null) {
            try {
                sensors.unregisterListener(this);
            } catch (Exception ignored) {
            }
        }
    }

    private void acquireCpu() {
        if (cpuLock != null && !cpuLock.isHeld()) cpuLock.acquire();
    }

    // ---------------------------------------------------------------- sensors

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (!armed || ringing) return;
        int type = e.sensor.getType();
        if (type == Sensor.TYPE_ACCELEROMETER) {
            float x = e.values[0];
            float y = e.values[1];
            float z = e.values[2];
            if (hasLast) {
                float dx = x - lx;
                float dy = y - ly;
                float dz = z - lz;
                double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (d > motionThreshold) {
                    long now = SystemClock.elapsedRealtime();
                    if (hits == 0 || now - firstHitAt > 2000) {
                        hits = 1;
                        firstHitAt = now;
                    } else {
                        hits++;
                    }
                    if (hits >= 2) {
                        trigger("motion", true);
                    }
                }
            }
            lx = x;
            ly = y;
            lz = z;
            hasLast = true;
        } else if (type == Sensor.TYPE_PROXIMITY) {
            boolean near = e.values[0] < Math.min(5f, e.sensor.getMaximumRange());
            if (near) {
                sawNear = true;
            } else if (sawNear) {
                trigger("pocket", true);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    // ---------------------------------------------------------------- alarm

    private void trigger(String code, boolean log) {
        if (ringing) return;
        ringing = true;
        arming = false;
        armingEndsAt = 0L;
        reason = code;
        handler.removeCallbacks(armNowTask);
        stopSensors();
        JSONObject c = readCfg();
        volLock = c.optBoolean("volumeLock", true);
        flashOn = c.optBoolean("flash", true);
        vibrateOn = c.optBoolean("vibrate", true);
        prefs().edit().putBoolean("ringing", true).putString("reason", code).apply();
        if (log) LogStore.add(this, code);
        acquireCpu();
        wakeScreen();
        startSound();
        if (vibrateOn) startVibration();
        if (flashOn) startTorch();
        postAlarmNotification();
        updateGuardNotification();
        handler.removeCallbacks(enforcer);
        handler.postDelayed(enforcer, 250);
    }

    private void wakeScreen() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (screenLock != null && screenLock.isHeld()) screenLock.release();
            screenLock = pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "alertme:screen");
            screenLock.acquire(15000L);
        } catch (Exception ignored) {
        }
    }

    private void startSound() {
        try {
            maxAlarmVol = audio.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            audio.setStreamVolume(AudioManager.STREAM_ALARM, maxAlarmVol, 0);
            String tone = readCfg().optString("tone", "siren");
            int resId = getResources().getIdentifier(tone, "raw", getPackageName());
            if (resId == 0) resId = R.raw.siren;
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            if (focusReq == null) {
                focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                        .setAudioAttributes(attrs)
                        .setOnAudioFocusChangeListener(change -> { })
                        .build();
                audio.requestAudioFocus(focusReq);
            }
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(attrs);
            AssetFileDescriptor afd = getResources().openRawResourceFd(resId);
            try {
                mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            } finally {
                afd.close();
            }
            mp.setLooping(true);
            mp.setVolume(1f, 1f);
            mp.setOnErrorListener((m, what, extra) -> {
                releasePlayer();
                return true;
            });
            mp.prepare();
            mp.start();
            player = mp;
        } catch (Exception e) {
            releasePlayer();
        }
    }

    private boolean playerHealthy() {
        try {
            return player != null && player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }

    private void releasePlayer() {
        if (player != null) {
            try {
                player.stop();
            } catch (Exception ignored) {
            }
            try {
                player.release();
            } catch (Exception ignored) {
            }
            player = null;
        }
    }

    @SuppressWarnings("deprecation")
    private void startVibration() {
        try {
            vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator == null || !vibrator.hasVibrator()) return;
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 700, 300}, 0), attrs);
        } catch (Exception ignored) {
        }
    }

    private void startTorch() {
        try {
            camera = (CameraManager) getSystemService(CAMERA_SERVICE);
            torchId = null;
            for (String id : camera.getCameraIdList()) {
                Boolean flash = camera.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (flash != null && flash) {
                    torchId = id;
                    break;
                }
            }
            if (torchId != null) {
                handler.removeCallbacks(torchTask);
                handler.post(torchTask);
            }
        } catch (Exception ignored) {
        }
    }

    private void setTorch(boolean on) {
        if (camera == null || torchId == null) return;
        try {
            camera.setTorchMode(torchId, on);
            torchOn = on;
        } catch (Exception ignored) {
        }
    }

    private void stopRinging() {
        releasePlayer();
        if (focusReq != null && audio != null) {
            try {
                audio.abandonAudioFocusRequest(focusReq);
            } catch (Exception ignored) {
            }
        }
        focusReq = null;
        if (vibrator != null) {
            try {
                vibrator.cancel();
            } catch (Exception ignored) {
            }
        }
        setTorch(false);
        torchOn = false;
        if (screenLock != null && screenLock.isHeld()) screenLock.release();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(ID_ALARM);
    }

    // ---------------------------------------------------------------- notifications

    private void createChannels() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel guard = new NotificationChannel(
                CH_GUARD, getString(R.string.channel_guard), NotificationManager.IMPORTANCE_LOW);
        guard.setShowBadge(false);
        NotificationChannel alarm = new NotificationChannel(
                CH_ALARM, getString(R.string.channel_alarm), NotificationManager.IMPORTANCE_HIGH);
        alarm.setSound(null, null);
        alarm.enableVibration(false);
        alarm.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(guard);
        nm.createNotificationChannel(alarm);
    }

    private Intent openAppIntent() {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.putExtra(EXTRA_ALARM, ringing);
        return i;
    }

    private Notification guardNotification() {
        int title = ringing ? R.string.notif_alarm_title : (armed ? R.string.notif_armed_title : R.string.notif_arming_title);
        int text = ringing ? R.string.notif_alarm_text : (armed ? R.string.notif_armed_text : R.string.notif_arming_text);
        PendingIntent pi = PendingIntent.getActivity(this, 0, openAppIntent(),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CH_GUARD)
                .setSmallIcon(R.drawable.ic_stat_alert)
                .setContentTitle(getString(title))
                .setContentText(getString(text))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi)
                .setColor(0xFF0A64F0)
                .build();
    }

    private void updateGuardNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(ID_GUARD, guardNotification());
    }

    private void goForeground() {
        Notification n = guardNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_GUARD, n,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID_GUARD, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(ID_GUARD, n);
        }
    }

    private void postAlarmNotification() {
        try {
            Intent open = openAppIntent();
            PendingIntent pi = PendingIntent.getActivity(this, 1, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification n = new Notification.Builder(this, CH_ALARM)
                    .setSmallIcon(R.drawable.ic_stat_alert)
                    .setContentTitle(getString(R.string.notif_alarm_title))
                    .setContentText(getString(R.string.notif_alarm_text))
                    .setCategory(Notification.CATEGORY_ALARM)
                    .setOngoing(true)
                    .setAutoCancel(false)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setFullScreenIntent(pi, true)
                    .setContentIntent(pi)
                    .setColor(0xFFFF3B14)
                    .build();
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(ID_ALARM, n);
            try {
                startActivity(open);
            } catch (Exception ignored) {
                // Background activity starts can be blocked; the full-screen intent covers that.
            }
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- helpers

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, 0);
    }

    private JSONObject readCfg() {
        try {
            return new JSONObject(prefs().getString("config", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }
}
