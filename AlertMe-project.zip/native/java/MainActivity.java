package com.alertme.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AlertPlugin.class);
        super.onCreate(savedInstanceState);

        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#EAF2FF"));
        w.setNavigationBarColor(Color.parseColor("#EAF2FF"));
        WindowInsetsControllerCompat bars = WindowCompat.getInsetsController(w, w.getDecorView());
        bars.setAppearanceLightStatusBars(true);
        bars.setAppearanceLightNavigationBars(true);

        Intent in = getIntent();
        boolean fromAlarm = in != null && in.getBooleanExtra(GuardService.EXTRA_ALARM, false);
        applyAlarmFlags(GuardService.ringing || fromAlarm);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra(GuardService.EXTRA_ALARM, false)) {
            applyAlarmFlags(true);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        applyAlarmFlags(GuardService.ringing);
    }

    /** Lets the alarm screen appear over the lock screen and wakes the display. */
    private void applyAlarmFlags(boolean on) {
        setShowWhenLocked(on);
        setTurnScreenOn(on);
        if (on) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    /** While the alarm rings, the volume keys do nothing. */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int k = event.getKeyCode();
        boolean volumeKey = k == KeyEvent.KEYCODE_VOLUME_UP
                || k == KeyEvent.KEYCODE_VOLUME_DOWN
                || k == KeyEvent.KEYCODE_VOLUME_MUTE;
        if (volumeKey && GuardService.ringing && GuardService.volumeLockOn(this)) {
            return true;
        }
        return super.dispatchKeyEvent(event);
    }
}
