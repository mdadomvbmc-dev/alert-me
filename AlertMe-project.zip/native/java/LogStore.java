package com.alertme.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Keeps the last alarms (newest first) so the history survives restarts. */
final class LogStore {
    private static final String KEY = "log";
    private static final int MAX = 50;

    private LogStore() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(GuardService.PREFS, 0);
    }

    static synchronized void add(Context c, String code) {
        try {
            JSONArray old = new JSONArray(prefs(c).getString(KEY, "[]"));
            JSONArray out = new JSONArray();
            JSONObject entry = new JSONObject();
            entry.put("t", System.currentTimeMillis());
            entry.put("r", code);
            out.put(entry);
            for (int i = 0; i < old.length() && out.length() < MAX; i++) {
                out.put(old.get(i));
            }
            prefs(c).edit().putString(KEY, out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static synchronized String json(Context c) {
        return prefs(c).getString(KEY, "[]");
    }

    static synchronized void clear(Context c) {
        prefs(c).edit().putString(KEY, "[]").apply();
    }
}
