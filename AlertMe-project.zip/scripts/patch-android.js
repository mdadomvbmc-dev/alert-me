#!/usr/bin/env node
/*
 * Runs in CI right after `npx cap add android`.
 * Copies the custom native code/resources into the generated Android project
 * and patches the few Gradle values we need. Every patch is verified: if
 * something is not found the build stops with a clear message instead of
 * silently producing a broken app.
 */
'use strict';
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const mainDir = path.join(root, 'android', 'app', 'src', 'main');
const APP_ID = 'com.alertme.app';

function fail(msg) {
  console.error('PATCH ERROR: ' + msg);
  process.exit(1);
}

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name);
    const d = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}

function removeNamed(dir, fileName) {
  let n = 0;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) n += removeNamed(p, fileName);
    else if (e.name === fileName) { fs.unlinkSync(p); n++; }
  }
  return n;
}

function patchFile(file, regex, replacement, label) {
  if (!fs.existsSync(file)) fail(file + ' not found');
  const text = fs.readFileSync(file, 'utf8');
  if (!regex.test(text)) fail(label + ' not found in ' + file);
  fs.writeFileSync(file, text.replace(regex, replacement));
  console.log('patched: ' + label);
}

if (!fs.existsSync(mainDir)) fail('android project missing - run "npx cap add android" first');

// 0. repository name for the in-app updater
if (process.env.GITHUB_REPOSITORY) {
  fs.writeFileSync(
    path.join(root, 'www', 'config.js'),
    'window.APP_CONFIG = { repo: ' + JSON.stringify(process.env.GITHUB_REPOSITORY) + ' };\n'
  );
  console.log('repo set to ' + process.env.GITHUB_REPOSITORY);
}

// 1. native java
const javaDir = path.join(mainDir, 'java', ...APP_ID.split('.'));
fs.mkdirSync(javaDir, { recursive: true });
const javaFiles = fs.readdirSync(path.join(root, 'native', 'java')).filter((f) => f.endsWith('.java'));
if (javaFiles.length === 0) fail('no java files in native/java');
for (const f of javaFiles) fs.copyFileSync(path.join(root, 'native', 'java', f), path.join(javaDir, f));
console.log('java files: ' + javaFiles.join(', '));

// 2. resources (icons, sounds, strings, styles ...)
copyDir(path.join(root, 'native', 'res'), path.join(mainDir, 'res'));

// 3. manifest
fs.copyFileSync(path.join(root, 'native', 'AndroidManifest.xml'), path.join(mainDir, 'AndroidManifest.xml'));

// 4. drop the default Capacitor splash images (we use our own splash_bg)
console.log('removed default splash images: ' + removeNamed(path.join(mainDir, 'res'), 'splash.png'));

// 5. gradle values
patchFile(path.join(root, 'android', 'variables.gradle'), /minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 27', 'minSdkVersion');

const appGradle = path.join(root, 'android', 'app', 'build.gradle');
const vCode = parseInt(process.env.VERSION_CODE || '1', 10);
const vName = process.env.VERSION_NAME || '1.0.0';
if (!Number.isInteger(vCode) || vCode < 1) fail('VERSION_CODE invalid');
patchFile(appGradle, /versionCode\s+\d+/, 'versionCode ' + vCode, 'versionCode');
patchFile(appGradle, /versionName\s+"[^"]*"/, 'versionName "' + vName + '"', 'versionName');
if (!fs.readFileSync(appGradle, 'utf8').includes(APP_ID)) fail('applicationId is not ' + APP_ID);

let g = fs.readFileSync(appGradle, 'utf8');
if (!g.includes('// alertme-lint')) {
  g += '\n// alertme-lint\nandroid {\n    lint {\n        abortOnError = false\n        checkReleaseBuilds = false\n    }\n}\n';
  fs.writeFileSync(appGradle, g);
  console.log('patched: lint options');
}
console.log('patch complete');
