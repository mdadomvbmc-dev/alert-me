// The GitHub Actions build overwrites this file with your real repository name
// (used by the in-app update checker). Nothing to edit by hand.
window.APP_CONFIG = { repo: "" };
