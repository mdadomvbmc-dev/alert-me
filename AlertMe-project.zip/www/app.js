(function () {
  'use strict';

  /* ------------------------------------------------------------------ helpers */
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/\d/g, function (d) { return BN[d]; }); }
  function toEn(s) { return String(s).replace(/[০-৯]/g, function (d) { return String(BN.indexOf(d)); }); }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  var MONTHS = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  function fmtTime(ts) {
    var d = new Date(ts);
    var h = d.getHours();
    var part = h < 5 ? 'রাত' : h < 12 ? 'সকাল' : h < 16 ? 'দুপুর' : h < 18 ? 'বিকাল' : h < 20 ? 'সন্ধ্যা' : 'রাত';
    var h12 = h % 12 || 12;
    var mm = String(d.getMinutes()).padStart(2, '0');
    var yr = d.getFullYear() !== new Date().getFullYear() ? ' ' + bn(d.getFullYear()) : '';
    return bn(d.getDate()) + ' ' + MONTHS[d.getMonth()] + yr + ', ' + part + ' ' + bn(h12) + ':' + bn(mm);
  }
  function fmtClock(sec) {
    var m = Math.floor(sec / 60);
    var s = sec % 60;
    return bn(String(m).padStart(2, '0')) + ':' + bn(String(s).padStart(2, '0'));
  }
  function cmpVer(a, b) {
    var x = String(a).split('.').map(function (n) { return parseInt(n, 10) || 0; });
    var y = String(b).split('.').map(function (n) { return parseInt(n, 10) || 0; });
    for (var i = 0; i < Math.max(x.length, y.length); i++) {
      var d = (x[i] || 0) - (y[i] || 0);
      if (d !== 0) return d > 0 ? 1 : -1;
    }
    return 0;
  }

  /* ------------------------------------------------------------------ icons */
  var P = {
    shield: '<path d="M12 3l7 3v5c0 4.5-3 8.2-7 10-4-1.8-7-5.5-7-10V6l7-3z"/>',
    shieldCheck: '<path d="M12 3l7 3v5c0 4.5-3 8.2-7 10-4-1.8-7-5.5-7-10V6l7-3z"/><path d="M9 12l2 2 4-4"/>',
    motion: '<rect x="8" y="3" width="8" height="18" rx="2"/><path d="M4 8v8M20 8v8M2 10.5v3M22 10.5v3"/>',
    plug: '<path d="M9 3v5M15 3v5M7 8h10v4a5 5 0 0 1-10 0V8z"/><path d="M12 17v4"/>',
    pocket: '<path d="M5 9h14l-1.2 10.2a2 2 0 0 1-2 1.8H8.2a2 2 0 0 1-2-1.8L5 9z"/><path d="M12 15V3m0 0L8.5 6.5M12 3l3.5 3.5"/>',
    bell: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15L6 16z"/><path d="M10 21a2 2 0 0 0 4 0"/>',
    history: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    settings: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
    home: '<path d="M4 11l8-7 8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1v-8z"/>',
    battery: '<rect x="3" y="8" width="16" height="9" rx="2.5"/><path d="M21 11v3"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6l1-7z"/>',
    play: '<path d="M8 5v14l11-7L8 5z" fill="currentColor"/>',
    warning: '<path d="M12 4l9 16H3L12 4z"/><path d="M12 10v4M12 17.5v.5"/>',
    download: '<path d="M12 4v11m0 0l-4-4m4 4l4-4M5 20h14"/>',
    trash: '<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A15 15 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.5"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6"/>',
    stop: '<path d="M6 6l12 12M18 6L6 18"/>',
    volume: '<path d="M4 10v4h4l5 4V6l-5 4H4z"/><path d="M16.5 9a4 4 0 0 1 0 6"/>',
    flash: '<path d="M9 3h6l-1.5 6H17l-7 12 1-8H7l2-10z"/>',
    vibrate: '<rect x="8" y="3" width="8" height="18" rx="2"/><path d="M4 8v8M20 8v8"/>',
    unlock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 7.5-2"/>'
  };
  function ic(name, extra) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"' +
      (extra || '') + ' aria-hidden="true">' + P[name] + '</svg>';
  }

  /* ------------------------------------------------------------------ native bridge */
  function createMock() {
    var m = { armed: false, arming: false, endsAt: 0, ringing: false, reason: '', logs: [], cfg: {} };
    var t = null;
    return {
      getState: function () {
        return Promise.resolve({ armed: m.armed, arming: m.arming, armingEndsAt: m.endsAt, ringing: m.ringing, reason: m.reason, now: Date.now(), battery: 76, charging: false });
      },
      saveConfig: function (o) { m.cfg = JSON.parse(o.json); return Promise.resolve(); },
      arm: function () {
        var d = (m.cfg.delaySec || 10) * 1000;
        m.arming = true; m.endsAt = Date.now() + d;
        t = setTimeout(function () { m.arming = false; m.armed = true; m.endsAt = 0; }, d);
        return Promise.resolve();
      },
      disarm: function () { clearTimeout(t); m.armed = m.arming = m.ringing = false; m.endsAt = 0; return Promise.resolve(); },
      testAlarm: function () { m.ringing = true; m.reason = 'test'; m.logs.unshift({ t: Date.now(), r: 'test' }); return Promise.resolve(); },
      stopAlarm: function () { m.ringing = false; m.armed = m.arming = false; return Promise.resolve({ stopped: true }); },
      getLogs: function () { return Promise.resolve({ json: JSON.stringify(m.logs) }); },
      clearLogs: function () { m.logs = []; return Promise.resolve(); },
      getPermissions: function () { return Promise.resolve({ sdk: 34, notifications: true, battery: false, fullScreen: true, install: false }); },
      requestPermission: function () { return Promise.resolve(); },
      previewTone: function () { return Promise.resolve(); },
      stopPreviewTone: function () { return Promise.resolve(); },
      getAppInfo: function () { return Promise.resolve({ versionName: '1.0.0', versionCode: 1 }); },
      installUpdate: function () { return Promise.resolve({ needPermission: true }); },
      addListener: function () { return Promise.resolve({ remove: function () {} }); }
    };
  }
  var isNative = !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
  // Plain (non-bundled) Capacitor apps expose plugins as Capacitor.Plugins.<Name>.
  var nativePlugin = null;
  if (isNative) {
    nativePlugin = (window.Capacitor.Plugins && window.Capacitor.Plugins.AlertPlugin) ||
      (typeof window.Capacitor.registerPlugin === 'function' ? window.Capacitor.registerPlugin('AlertPlugin') : null);
  }
  var Native = nativePlugin || createMock();

  /* ------------------------------------------------------------------ config */
  var DEFAULTS = {
    motion: true, charger: false, pocket: false,
    delaySec: 10, sens: 2, tone: 'siren',
    flash: true, vibrate: true, volumeLock: true, autoStopOnUnlock: false,
    ownerMsg: '', ownerPhone: ''
  };
  var CFG_KEY = 'alertme.cfg';
  function loadCfg() {
    var out = {};
    var k;
    for (k in DEFAULTS) out[k] = DEFAULTS[k];
    try {
      var saved = JSON.parse(localStorage.getItem(CFG_KEY) || '{}');
      for (k in DEFAULTS) {
        if (saved[k] !== undefined && typeof saved[k] === typeof DEFAULTS[k]) out[k] = saved[k];
      }
    } catch (e) { /* ignore */ }
    if ([5, 10, 20, 30].indexOf(out.delaySec) < 0) out.delaySec = 10;
    if ([1, 2, 3].indexOf(out.sens) < 0) out.sens = 2;
    if (['siren', 'police', 'beep_alarm'].indexOf(out.tone) < 0) out.tone = 'siren';
    return out;
  }
  var cfg = loadCfg();
  var saveTimer = null;
  function pushCfg() {
    try { localStorage.setItem(CFG_KEY, JSON.stringify(cfg)); } catch (e) { /* ignore */ }
    return Promise.resolve(Native.saveConfig({ json: JSON.stringify(cfg) })).catch(function () {});
  }
  function saveSoon() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(pushCfg, 350);
  }

  /* ------------------------------------------------------------------ static data */
  var MODES = [
    { k: 'motion', ic: 'motion', cls: '', t: 'নড়াচড়া বা তুলে নিলে', d: 'কেউ ফোন নাড়ালে বা তুলে নিলে অ্যালার্ম বাজবে।' },
    { k: 'charger', ic: 'plug', cls: 'amber', t: 'চার্জার খুললে', d: 'চার্জারে লাগানো ফোনের চার্জার খুললেই অ্যালার্ম বাজবে।' },
    { k: 'pocket', ic: 'pocket', cls: 'green', t: 'পকেট থেকে বের করলে', d: 'পকেট বা ব্যাগে রেখে চালু করুন, বের করলেই অ্যালার্ম বাজবে।' }
  ];
  var MODE_SHORT = { motion: 'নড়াচড়া', charger: 'চার্জার', pocket: 'পকেট' };
  var TONES = [
    { id: 'siren', t: 'সাইরেন', d: 'ওঠানামা করা তীব্র সাইরেন' },
    { id: 'police', t: 'পুলিশ সাইরেন', d: 'দ্রুত বদলানো দুই সুর' },
    { id: 'beep_alarm', t: 'তীক্ষ্ণ বিপ', d: 'পরপর তিনটি জোরালো বিপ' }
  ];
  var REASONS = {
    motion: { t: 'ফোনটি নাড়ানো বা তুলে নেওয়া হয়েছে', ic: 'motion', cls: '' },
    charger: { t: 'চার্জার খুলে ফেলা হয়েছে', ic: 'plug', cls: 'amber' },
    pocket: { t: 'ফোন পকেট বা ব্যাগ থেকে বের করা হয়েছে', ic: 'pocket', cls: 'green' },
    test: { t: 'এটি একটি পরীক্ষামূলক অ্যালার্ম', ic: 'bell', cls: '' }
  };
  function reasonOf(code) { return REASONS[code] || REASONS.motion; }

  /* ------------------------------------------------------------------ state */
  var S = {
    tab: 'home',
    st: { armed: false, arming: false, ringing: false, armingEndsAt: 0, reason: '', battery: -1, charging: false },
    skew: 0,
    perms: null,
    logs: [],
    app: { versionName: '', versionCode: 0 },
    upd: { state: 'idle' },
    alarmSince: 0,
    stopping: false,
    renderedMode: 'off'
  };
  function modeOf(st) { return st.ringing ? 'ring' : st.arming ? 'arming' : st.armed ? 'on' : 'off'; }
  function busy() { return S.st.armed || S.st.arming || S.st.ringing; }
  function secondsLeft() {
    return Math.max(0, Math.ceil((S.st.armingEndsAt - (Date.now() + S.skew)) / 1000));
  }

  /* ------------------------------------------------------------------ view builders */
  function switchBtn(k, disabled) {
    var on = !!cfg[k];
    return '<button class="sw' + (on ? ' on' : '') + '" role="switch" aria-checked="' + on + '" data-act="toggle" data-v="' + k + '"' + (disabled ? ' disabled' : '') + '><i></i></button>';
  }
  function optRow(k, icon, cls, title, desc) {
    return '<div class="row"><span class="ico ' + cls + '">' + ic(icon) + '</span><div class="row-text"><b>' + title + '</b><small>' + desc + '</small></div>' + switchBtn(k, false) + '</div>';
  }

  function chipsHTML() {
    var st = S.st;
    var out = '';
    if (st.battery >= 0) {
      var low = st.battery <= 15 && !st.charging;
      out += '<span class="chip' + (low ? ' low' : '') + '">' + ic('battery') + 'ব্যাটারি ' + bn(st.battery) + '%</span>';
    }
    if (st.charging) out += '<span class="chip good">' + ic('bolt') + 'চার্জ হচ্ছে</span>';
    if (st.armed || st.arming) {
      MODES.forEach(function (m) {
        if (cfg[m.k]) out += '<span class="chip">' + ic(m.ic) + MODE_SHORT[m.k] + '</span>';
      });
    }
    return out;
  }

  function heroHTML() {
    var mode = modeOf(S.st);
    var cls, core, title, sub, btn;
    if (mode === 'arming') {
      cls = 'state-arming';
      core = '<span class="count" id="count">' + bn(secondsLeft()) + '</span>';
      title = 'প্রস্তুত হচ্ছে';
      sub = '';
      btn = '<button class="btn ghost wide" data-act="toggleArm">' + ic('stop') + 'বাতিল করুন</button>';
    } else if (mode === 'on') {
      cls = 'state-on';
      core = ic('shieldCheck');
      title = 'ফোন সুরক্ষিত আছে';
      sub = 'কেউ ফোনে হাত দিলেই অ্যালার্ম বাজবে।';
      btn = '<button class="btn danger wide" data-act="toggleArm">' + ic('unlock') + 'সুরক্ষা বন্ধ করুন</button>';
    } else {
      cls = 'state-off';
      core = ic('shield');
      title = 'সুরক্ষা বন্ধ আছে';
      sub = 'নিচের বোতাম চেপে পাহারা শুরু করুন।';
      btn = '<button class="btn primary wide" data-act="toggleArm">' + ic('shield') + 'পাহারা শুরু করুন</button>';
    }
    var label = mode === 'off' ? 'পাহারা শুরু করুন' : mode === 'on' ? 'সুরক্ষা বন্ধ করুন' : 'বাতিল করুন';
    return '<section class="hero glass ' + cls + '" id="hero">' +
      '<button class="orb" data-act="toggleArm" aria-label="' + label + '"><span class="ring r1"></span><span class="ring r2"></span><span class="core">' + core + '</span></button>' +
      '<h1 class="hero-title">' + title + '</h1>' +
      '<p class="hero-sub" id="heroSub">' + (mode === 'arming' ? subArming() : sub) + '</p>' +
      '<div class="chips" id="chips">' + chipsHTML() + '</div>' + btn + '</section>';
  }
  function subArming() {
    return 'ফোনটি নামিয়ে রাখুন। ' + bn(secondsLeft()) + ' সেকেন্ড পরে পাহারা শুরু হবে।';
  }

  function bannersHTML() {
    var out = '';
    var p = S.perms;
    if (p && (!p.notifications || !p.battery)) {
      out += '<div class="banner glass warn"><span class="ico amber">' + ic('warning') + '</span><div class="b-text"><b>সেটআপ বাকি আছে</b>নোটিফিকেশন ও ব্যাটারি অনুমতি না দিলে পাহারা বন্ধ হয়ে যেতে পারে।</div>' +
        '<button class="btn ghost small" data-act="tab" data-v="settings">ঠিক করুন</button></div>';
    }
    if (S.upd.state === 'available') {
      out += '<div class="banner glass info"><span class="ico">' + ic('download') + '</span><div class="b-text"><b>নতুন আপডেট এসেছে</b>ভার্সন ' + esc(bn(S.upd.latest)) + ' ডাউনলোডের জন্য প্রস্তুত।</div>' +
        '<button class="btn ghost small" data-act="tab" data-v="settings">দেখুন</button></div>';
    }
    return out;
  }

  function homeHTML() {
    var locked = busy();
    var modesHTML = MODES.map(function (m) {
      return '<div class="row"><span class="ico ' + m.cls + '">' + ic(m.ic) + '</span><div class="row-text"><b>' + m.t + '</b><small>' + m.d + '</small></div>' + switchBtn(m.k, locked) + '</div>';
    }).join('');
    var delays = [5, 10, 20, 30].map(function (n) {
      return '<button class="' + (cfg.delaySec === n ? 'on' : '') + '" data-act="delay" data-v="' + n + '"' + (locked ? ' disabled' : '') + '>' + bn(n) + ' সে.</button>';
    }).join('');
    var senses = [[1, 'কম'], [2, 'মাঝারি'], [3, 'বেশি']].map(function (s) {
      return '<button class="' + (cfg.sens === s[0] ? 'on' : '') + '" data-act="sens" data-v="' + s[0] + '"' + (locked ? ' disabled' : '') + '>' + s[1] + '</button>';
    }).join('');
    return bannersHTML() + heroHTML() +
      '<section class="card glass"><h2 class="card-title">গার্ড মোড</h2><p class="hint">কোন ঘটনায় অ্যালার্ম বাজবে বেছে নিন। একসাথে একাধিক চালু রাখা যায়।</p><div class="rows">' + modesHTML + '</div></section>' +
      '<section class="card glass"><h2 class="card-title">চালুর আগে সময়</h2><p class="hint">বোতাম চাপার পর এই সময়ের মধ্যে ফোনটি রেখে সরে যান।</p><div class="seg">' + delays + '</div>' +
      '<h3 class="sub-title">নড়াচড়ার সংবেদনশীলতা</h3><div class="seg">' + senses + '</div>' +
      '<p class="hint">বেশি দিলে সামান্য নাড়াচাড়াতেই বাজবে, কম দিলে জোরে নাড়ালে বাজবে।</p></section>' +
      '<section class="tip glass"><span class="ico red">' + ic('lock') + '</span><p><b>পরামর্শ:</b> ফোনে পিন বা প্যাটার্ন লক দিন। লক না থাকলে চোর আনলক ছাড়াই অ্যালার্ম বন্ধ করে দিতে পারে।</p></section>' +
      '<button class="btn ghost wide" data-act="test"' + (locked ? ' disabled' : '') + '>' + ic('bell') + 'অ্যালার্ম পরীক্ষা করুন</button>';
  }

  function permRow(name, icon, title, desc, ok) {
    return '<div class="row"><span class="ico ' + (ok ? 'green' : 'amber') + '">' + ic(icon) + '</span><div class="row-text"><b>' + title + '</b><small>' + desc + '</small></div>' +
      (ok ? '<span class="chip-state ok">চালু</span>' : '<button class="btn ghost small" data-act="perm" data-v="' + name + '">ঠিক করুন</button>') + '</div>';
  }

  function updateCardHTML() {
    var u = S.upd;
    var ver = S.app.versionName ? 'বর্তমান ভার্সন: ' + esc(bn(S.app.versionName)) : '';
    var body = '';
    if (u.state === 'checking') {
      body = '<p class="status-line">আপডেট খোঁজা হচ্ছে…</p>';
    } else if (u.state === 'latest') {
      body = '<p class="status-line good">আপনি সর্বশেষ ভার্সন ব্যবহার করছেন।</p>' +
        '<div class="actions"><button class="btn ghost wide" data-act="checkUpdate">' + ic('refresh') + 'আবার দেখুন</button></div>';
    } else if (u.state === 'available' || u.state === 'downloading') {
      var dl = u.state === 'downloading';
      body = '<p class="status-line good">নতুন ভার্সন ' + esc(bn(u.latest)) + ' পাওয়া গেছে।</p>' +
        (u.notes ? '<div class="notes">' + esc(u.notes) + '</div>' : '') +
        (dl ? '<div class="bar"><i id="updBar" style="width:' + (u.pct || 0) + '%"></i></div><p class="status-line" id="updPct">ডাউনলোড হচ্ছে ' + bn(u.pct || 0) + '%</p>' : '') +
        '<div class="actions"><button class="btn primary wide" data-act="doUpdate"' + (dl ? ' disabled' : '') + '>' + ic('download') + (dl ? 'ডাউনলোড চলছে…' : 'ডাউনলোড ও ইনস্টল করুন') + '</button></div>';
    } else if (u.state === 'error') {
      body = '<p class="status-line bad">' + (u.msg === 'norelease' ? 'এখনো কোনো রিলিজ পাওয়া যায়নি।' : 'ইন্টারনেট সংযোগ নেই বা সার্ভারে পৌঁছানো যায়নি।') + '</p>' +
        '<div class="actions"><button class="btn ghost wide" data-act="checkUpdate">' + ic('refresh') + 'আবার চেষ্টা করুন</button></div>';
    } else if (u.state === 'norepo') {
      body = '<p class="status-line bad">এই বিল্ডে GitHub রিপোজিটরির তথ্য নেই। GitHub Actions দিয়ে বিল্ড করলে এটি নিজে থেকে বসে যাবে।</p>';
    } else {
      body = '<div class="actions"><button class="btn ghost wide" data-act="checkUpdate">' + ic('refresh') + 'আপডেট আছে কিনা দেখুন</button></div>';
    }
    return '<section class="card glass"><h2 class="card-title">অ্যাপ আপডেট</h2><p class="version">' + ver + '</p>' + body + '</section>';
  }

  function settingsHTML() {
    var tones = TONES.map(function (t) {
      var on = cfg.tone === t.id;
      return '<div class="row"><button class="tone' + (on ? ' on' : '') + '" data-act="tone" data-v="' + t.id + '" aria-pressed="' + on + '">' +
        '<span class="radio"></span><span class="row-text"><b>' + t.t + '</b><small>' + t.d + '</small></span></button>' +
        '<button class="play" data-act="preview" data-v="' + t.id + '" aria-label="' + t.t + ' শুনুন">' + ic('play') + '</button></div>';
    }).join('');
    var p = S.perms;
    var perms;
    if (!p) {
      perms = '<p class="hint">যাচাই করা হচ্ছে…</p>';
    } else {
      perms = '<div class="rows">' +
        permRow('notifications', 'bell', 'নোটিফিকেশন', 'অ্যালার্মের সময় স্ক্রিন জাগাতে লাগে।', p.notifications) +
        permRow('battery', 'battery', 'ব্যাটারি সেভার থেকে ছাড়', 'ব্যাকগ্রাউন্ডে পাহারা চালু রাখে।', p.battery) +
        (p.sdk >= 34 ? permRow('fullScreen', 'lock', 'লক স্ক্রিনে অ্যালার্ম স্ক্রিন', 'ফোন লক থাকলেও অ্যালার্মের পর্দা দেখায়।', p.fullScreen) : '') +
        permRow('install', 'download', 'অ্যাপ আপডেট ইনস্টল', 'অ্যাপের ভেতর থেকে আপডেট দিতে লাগে।', p.install) +
        '</div>';
    }
    return '<section class="card glass"><h2 class="card-title">অ্যালার্মের সুর</h2><p class="hint">পছন্দের সুর বেছে নিন। ▶ চেপে শুনে দেখতে পারেন।</p><div class="rows">' + tones + '</div></section>' +
      '<section class="card glass"><h2 class="card-title">অ্যালার্মের আচরণ</h2><div class="rows" style="margin-top:8px">' +
      optRow('volumeLock', 'volume', '', 'ভলিউম লক', 'অ্যালার্ম বাজার সময় ভলিউম সবসময় সর্বোচ্চ থাকবে, কমানো যাবে না।') +
      optRow('flash', 'flash', 'amber', 'ফ্ল্যাশলাইট জ্বলবে', 'অ্যালার্মের সাথে টর্চ জ্বলবে-নিভবে।') +
      optRow('vibrate', 'vibrate', 'green', 'ভাইব্রেশন', 'অ্যালার্মের সাথে ফোন কাঁপবে।') +
      optRow('autoStopOnUnlock', 'unlock', 'red', 'আনলক করলেই বন্ধ', 'চালু থাকলে ফোন আনলক করা মাত্র অ্যালার্ম থামবে। বন্ধ থাকলে আনলক করে অ্যাপ থেকে বন্ধ করতে হবে।') +
      '</div></section>' +
      '<section class="card glass"><h2 class="card-title">মালিকের বার্তা</h2><p class="hint">অ্যালার্ম বাজার সময় লক স্ক্রিনে এই বার্তা দেখা যাবে।</p>' +
      '<div class="field"><label for="fMsg">বার্তা</label><textarea id="fMsg" data-field="ownerMsg" maxlength="120" placeholder="যেমন: এটি আমার ফোন, দয়া করে ফেরত দিন।">' + esc(cfg.ownerMsg) + '</textarea></div>' +
      '<div class="field"><label for="fPhone">যোগাযোগের নম্বর</label><input id="fPhone" data-field="ownerPhone" type="tel" inputmode="tel" maxlength="20" placeholder="01XXXXXXXXX" value="' + esc(cfg.ownerPhone) + '"></div></section>' +
      '<section class="card glass"><h2 class="card-title">অনুমতি ও নিরাপত্তা</h2><p class="hint">সব ঠিক থাকলে পাহারা আরও নির্ভরযোগ্য হয়।</p>' + perms + '</section>' +
      updateCardHTML() +
      '<section class="tip glass"><span class="ico">' + ic('info') + '</span><p><b>জেনে রাখুন:</b> অ্যাপ বন্ধ করে দিলেও পাহারা চলতে থাকে। তবে Android কোনো অ্যাপকে ফোনের পাওয়ার-অফ আটকাতে দেয় না। তাই স্ক্রিন লক ও Find My Device চালু রাখুন।</p></section>';
  }

  function logHTML() {
    if (!S.logs.length) {
      return '<section class="empty glass"><span class="ico">' + ic('shieldCheck') + '</span><b>এখনো কোনো অ্যালার্ম বাজেনি</b><p>অ্যালার্ম বাজলে এখানে সময়সহ কারণ জমা থাকবে।</p></section>';
    }
    var rows = S.logs.map(function (l) {
      var r = reasonOf(l.r);
      return '<div class="row"><span class="ico ' + r.cls + '">' + ic(r.ic) + '</span><div class="row-text"><b>' + r.t + '</b></div><span class="time">' + esc(fmtTime(l.t)) + '</span></div>';
    }).join('');
    return '<section class="card glass"><h2 class="card-title">অ্যালার্মের ইতিহাস</h2><div class="rows" style="margin-top:8px">' + rows + '</div></section>' +
      '<button class="btn ghost wide" data-act="clearLog">' + ic('trash') + 'ইতিহাস মুছে ফেলুন</button>';
  }

  function alarmHTML() {
    var r = reasonOf(S.st.reason);
    var phone = toEn(cfg.ownerPhone).replace(/[^\d+]/g, '');
    var owner = '';
    if (cfg.ownerMsg || cfg.ownerPhone) {
      owner = '<div class="a-owner">' + (cfg.ownerMsg ? '<b>' + esc(cfg.ownerMsg) + '</b>' : '') +
        (phone ? '<a href="tel:' + esc(phone) + '">' + ic('phone') + esc(cfg.ownerPhone) + '</a>' : '') + '</div>';
    }
    return '<div class="a-bell"><span class="ring r1"></span><span class="ring r2"></span><span class="disc">' + ic('bell') + '</span></div>' +
      '<h1>অ্যালার্ম বাজছে!</h1><p class="a-reason">' + r.t + '</p><p class="a-timer" id="aTimer"></p>' + owner +
      '<button class="a-stop" data-act="stopAlarm">ফোন আনলক করে বন্ধ করুন</button>' +
      '<p class="a-help">লক স্ক্রিন খুললে তবেই অ্যালার্ম বন্ধ হবে।</p>';
  }

  /* ------------------------------------------------------------------ rendering */
  var view = $('#view');
  var TABS = [['home', 'হোম', 'home'], ['log', 'ইতিহাস', 'history'], ['settings', 'সেটিংস', 'settings']];
  function buildTabs() {
    TABS.forEach(function (t) {
      $('#tab-' + t[0]).innerHTML = ic(t[2]) + '<span>' + t[1] + '</span>';
    });
  }
  function updateTabs() {
    TABS.forEach(function (t) {
      var b = $('#tab-' + t[0]);
      b.classList.toggle('on', S.tab === t[0]);
      b.setAttribute('aria-current', S.tab === t[0] ? 'page' : 'false');
    });
  }
  function renderTop() {
    var mode = modeOf(S.st);
    var pill = $('#topPill');
    var map = { off: ['off', 'বন্ধ'], arming: ['arming', 'শুরু হচ্ছে'], on: ['on', 'চালু'], ring: ['ring', 'অ্যালার্ম!'] };
    pill.className = 'pill ' + map[mode][0];
    pill.textContent = map[mode][1];
  }
  function render() {
    var keep = view.scrollTop;
    var html = S.tab === 'home' ? homeHTML() : S.tab === 'log' ? logHTML() : settingsHTML();
    view.innerHTML = html;
    view.scrollTop = keep;
    updateTabs();
    renderTop();
    S.renderedMode = modeOf(S.st);
  }
  function softRender() {
    var a = document.activeElement;
    if (a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA')) return;
    render();
  }

  var toastTimer = null;
  function toast(msg) {
    var el = $('#toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2800);
  }

  /* ------------------------------------------------------------------ alarm overlay */
  function syncAlarm() {
    var el = $('#alarm');
    if (S.st.ringing) {
      if (el.hidden) {
        el.innerHTML = alarmHTML();
        el.hidden = false;
      }
      var t = $('#aTimer');
      if (t) t.textContent = 'বাজছে ' + fmtClock(Math.max(0, Math.floor((Date.now() - S.alarmSince) / 1000)));
    } else if (!el.hidden) {
      el.hidden = true;
      el.innerHTML = '';
      S.stopping = false;
      loadLogs();
    }
  }

  /* ------------------------------------------------------------------ data refresh */
  function refreshState(force) {
    return Promise.resolve(Native.getState()).then(function (n) {
      var prev = S.st;
      S.st = {
        armed: !!n.armed, arming: !!n.arming, ringing: !!n.ringing,
        armingEndsAt: Number(n.armingEndsAt) || 0,
        reason: n.reason || '',
        battery: typeof n.battery === 'number' ? n.battery : -1,
        charging: !!n.charging
      };
      S.skew = (Number(n.now) || Date.now()) - Date.now();
      if (S.st.ringing && !prev.ringing) S.alarmSince = Date.now();
      if (force || S.renderedMode !== modeOf(S.st)) {
        softRender();
      } else {
        tick();
      }
      syncAlarm();
    }).catch(function () {});
  }
  function tick() {
    if (S.tab !== 'home') return;
    if (S.st.arming) {
      var c = $('#count');
      var s = $('#heroSub');
      if (c) c.textContent = bn(secondsLeft());
      if (s) s.textContent = subArming();
    }
    var chips = $('#chips');
    if (chips) chips.innerHTML = chipsHTML();
  }
  function refreshPerms() {
    return Promise.resolve(Native.getPermissions()).then(function (p) {
      var changed = JSON.stringify(p) !== JSON.stringify(S.perms);
      S.perms = p;
      if (changed && (S.tab === 'settings' || S.tab === 'home')) softRender();
    }).catch(function () {});
  }
  function loadLogs() {
    return Promise.resolve(Native.getLogs()).then(function (r) {
      var arr = [];
      try { arr = JSON.parse((r && r.json) || '[]'); } catch (e) { arr = []; }
      S.logs = Array.isArray(arr) ? arr : [];
      if (S.tab === 'log') softRender();
    }).catch(function () {});
  }

  /* ------------------------------------------------------------------ actions */
  function toggleArm() {
    var st = S.st;
    if (st.ringing) return Promise.resolve();
    if (st.armed || st.arming) {
      return Promise.resolve(Native.disarm()).then(function () { return refreshState(true); });
    }
    if (!cfg.motion && !cfg.charger && !cfg.pocket) {
      toast('অন্তত একটি গার্ড মোড চালু করুন।');
      return Promise.resolve();
    }
    if (cfg.charger && !cfg.motion && !cfg.pocket && !st.charging) {
      toast('চার্জার মোডের জন্য আগে ফোনে চার্জার লাগান।');
      return Promise.resolve();
    }
    return pushCfg().then(function () { return Native.arm(); }).then(function () {
      if (cfg.charger && !S.st.charging) toast('চার্জার লাগানো নেই, তাই চার্জার মোড কাজ করবে না।');
      return refreshState(true);
    }).catch(function () { toast('পাহারা চালু করা যায়নি, আবার চেষ্টা করুন।'); });
  }

  function handleStop() {
    if (S.stopping) return;
    S.stopping = true;
    Promise.resolve(Native.stopAlarm()).then(function (r) {
      S.stopping = false;
      if (r && r.stopped === false) {
        toast('অ্যালার্ম বন্ধ করতে ফোন আনলক করতে হবে।');
        return null;
      }
      return refreshState(true);
    }).catch(function () {
      S.stopping = false;
      toast('বন্ধ করা যায়নি, আবার চেষ্টা করুন।');
    });
  }

  function checkUpdate(silent) {
    if (S.upd.state === 'checking' || S.upd.state === 'downloading') return Promise.resolve();
    var repo = (window.APP_CONFIG && window.APP_CONFIG.repo) || '';
    if (!repo) {
      S.upd = { state: silent ? 'idle' : 'norepo' };
      if (S.tab === 'settings') softRender();
      return Promise.resolve();
    }
    S.upd = { state: 'checking' };
    if (!silent && S.tab === 'settings') softRender();
    var ctl = typeof AbortController === 'function' ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctl) ctl.abort(); }, 12000);
    return fetch('https://api.github.com/repos/' + repo + '/releases/latest', {
      headers: { Accept: 'application/vnd.github+json' },
      cache: 'no-store',
      signal: ctl ? ctl.signal : undefined
    }).then(function (res) {
      clearTimeout(timer);
      if (res.status === 404) throw new Error('norelease');
      if (!res.ok) throw new Error('http');
      return res.json();
    }).then(function (j) {
      var asset = (j.assets || []).filter(function (a) { return /\.apk$/i.test(a.name || ''); })[0];
      var latest = String(j.tag_name || '').replace(/^v/i, '');
      if (!asset || !latest) throw new Error('norelease');
      if (cmpVer(latest, S.app.versionName || '0') > 0) {
        S.upd = { state: 'available', latest: latest, url: asset.browser_download_url, notes: String(j.body || '').trim().slice(0, 400), pct: 0 };
      } else {
        S.upd = { state: 'latest' };
      }
    }).catch(function (e) {
      clearTimeout(timer);
      S.upd = silent ? { state: 'idle' } : { state: 'error', msg: e && e.message === 'norelease' ? 'norelease' : 'net' };
    }).then(function () { softRender(); });
  }

  function startUpdate() {
    if (S.upd.state !== 'available') return Promise.resolve();
    var u = S.upd;
    S.upd = { state: 'downloading', latest: u.latest, url: u.url, notes: u.notes, pct: 0 };
    render();
    return Promise.resolve(Native.installUpdate({ url: u.url })).then(function (r) {
      S.upd = { state: 'available', latest: u.latest, url: u.url, notes: u.notes, pct: 0 };
      if (r && r.needPermission) toast('“অজানা উৎস থেকে ইনস্টল” অনুমতি দিয়ে ফিরে এসে আবার চাপ দিন।');
      else toast('ইনস্টল স্ক্রিন খুলেছে, “ইনস্টল” চাপুন।');
    }).catch(function () {
      S.upd = { state: 'available', latest: u.latest, url: u.url, notes: u.notes, pct: 0 };
      toast('ডাউনলোড ব্যর্থ হয়েছে। নেট দেখে আবার চেষ্টা করুন।');
    }).then(function () { render(); });
  }

  function act(name, v) {
    switch (name) {
      case 'tab':
        S.tab = v;
        if (v === 'log') loadLogs();
        if (v === 'settings') refreshPerms();
        render();
        view.scrollTop = 0;
        break;
      case 'toggleArm':
        toggleArm();
        break;
      case 'toggle':
        if ((v === 'motion' || v === 'charger' || v === 'pocket') && busy()) return;
        cfg[v] = !cfg[v];
        pushCfg();
        render();
        break;
      case 'delay':
        cfg.delaySec = Number(v);
        pushCfg();
        render();
        break;
      case 'sens':
        cfg.sens = Number(v);
        pushCfg();
        render();
        break;
      case 'tone':
        cfg.tone = v;
        pushCfg();
        render();
        break;
      case 'preview':
        Promise.resolve(Native.previewTone({ name: v })).catch(function () {});
        break;
      case 'test':
        if (busy()) { toast('আগে সুরক্ষা বন্ধ করুন।'); return; }
        pushCfg().then(function () { return Native.testAlarm(); }).then(function () {
          setTimeout(function () { refreshState(true); }, 300);
        }).catch(function () { toast('পরীক্ষা চালানো যায়নি।'); });
        break;
      case 'perm':
        Promise.resolve(Native.requestPermission({ name: v })).then(function () {
          setTimeout(refreshPerms, 800);
        }).catch(function () {});
        break;
      case 'checkUpdate':
        checkUpdate(false);
        break;
      case 'doUpdate':
        startUpdate();
        break;
      case 'clearLog':
        Promise.resolve(Native.clearLogs()).then(function () { S.logs = []; render(); });
        break;
      case 'stopAlarm':
        handleStop();
        break;
      default:
        break;
    }
  }

  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!el || el.disabled) return;
    act(el.getAttribute('data-act'), el.getAttribute('data-v'));
  });

  document.addEventListener('input', function (e) {
    var t = e.target;
    var f = t && t.getAttribute ? t.getAttribute('data-field') : null;
    if (!f) return;
    var val = t.value;
    if (f === 'ownerPhone') {
      var clean = val.replace(/[^\d০-৯+\-\s]/g, '').slice(0, 20);
      if (clean !== val) t.value = clean;
      val = clean;
    } else {
      val = val.slice(0, 120);
    }
    cfg[f] = val;
    saveSoon();
  });
  document.addEventListener('focusout', function (e) {
    if (e.target && e.target.getAttribute && e.target.getAttribute('data-field')) {
      clearTimeout(saveTimer);
      pushCfg();
    }
  });

  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'visible') {
      refreshState(true);
      refreshPerms();
    }
  });

  /* ------------------------------------------------------------------ boot */
  function init() {
    buildTabs();
    render();
    if (isNative && !nativePlugin) toast('নেটিভ অংশ লোড হয়নি, অ্যাপটি আবার ইনস্টল করুন।');
    Promise.resolve(Native.getAppInfo()).then(function (i) { if (i) S.app = i; }).catch(function () {})
      .then(pushCfg)
      .then(function () { return refreshState(true); })
      .then(refreshPerms)
      .then(loadLogs)
      .then(function () {
        try {
          if (S.perms && !S.perms.notifications && S.perms.sdk >= 33 && !localStorage.getItem('alertme.askedNotif')) {
            localStorage.setItem('alertme.askedNotif', '1');
            Native.requestPermission({ name: 'notifications' });
          }
        } catch (e) { /* ignore */ }
      });
    try {
      Promise.resolve(Native.addListener('updateProgress', function (p) {
        if (S.upd.state !== 'downloading') return;
        S.upd.pct = p && p.percent ? p.percent : 0;
        var bar = $('#updBar');
        var txt = $('#updPct');
        if (bar) bar.style.width = S.upd.pct + '%';
        if (txt) txt.textContent = 'ডাউনলোড হচ্ছে ' + bn(S.upd.pct) + '%';
      })).catch(function () {});
    } catch (e) { /* ignore */ }
    setInterval(function () {
      if (document.visibilityState === 'visible') refreshState(false);
    }, 500);
    setTimeout(function () { checkUpdate(true); }, 2500);
  }

  init();
})();
